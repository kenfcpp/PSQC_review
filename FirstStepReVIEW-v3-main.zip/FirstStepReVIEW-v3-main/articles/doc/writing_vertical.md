# Supporing Vertical Writing (experimental)

From Re:VIEW 2.0, Re:VIEW supports vertical writings, especially for Japanese document.

If you need any further information, please read [writing_vertical.ja.md](writing_vertical.ja.md) (in Japanese).
